﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MasterCardApi.Migrations
{
    /// <inheritdoc />
    public partial class AddBalanceOption : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "FirstName",
                table: "UserCards",
                newName: "Firstname");

            migrationBuilder.AddColumn<decimal>(
                name: "Balance",
                table: "UserCards",
                type: "decimal(18,2)",
                nullable: false,
                defaultValue: 0m);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Balance",
                table: "UserCards");

            migrationBuilder.RenameColumn(
                name: "Firstname",
                table: "UserCards",
                newName: "FirstName");
        }
    }
}
