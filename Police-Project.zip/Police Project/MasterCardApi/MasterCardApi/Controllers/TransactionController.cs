﻿using MasterCardApi.Dtos;
using MasterCardApi.Entities;
using MasterCardApi.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Storage;
using System.Transactions;

namespace MasterCardApi.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class TransactionController : ControllerBase
    {
        private readonly ITransactionService _transactionService;
        public TransactionController(ITransactionService transactionService)
        {
            _transactionService = transactionService;
        }

        [HttpPost("CashIn")]
        public ActionResult<TransactionDto> CashIn([FromBody] TransactionDto transactionDto)
        {
            var result = _transactionService.CashInTransaction(transactionDto);
            return Ok(result);
        }

        [HttpPost("CashOut")]
        public ActionResult<TransactionDto> CashOut([FromBody] TransactionDto transactionDto)
        {
            var result = _transactionService.CashOut(transactionDto);
            return Ok(result);
        }
    }
}
