﻿using MasterCardApi.Dtos;
using MasterCardApi.Entities;
using MasterCardApi.Repository;
using MasterCardApi.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Identity.Client.Extensibility;
using Microsoft.IdentityModel.Tokens;

namespace MasterCardApi.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class PaymentCardController : ControllerBase
    {
        private readonly ICardInfoService _cardInfoService;
        public PaymentCardController(ICardInfoService cardInfoService)
        {
            _cardInfoService = cardInfoService;
        }

        [HttpGet]
        public ActionResult<IEnumerable<UserCardsDto>> GetAllUserCard()
        {

            var allUserCards = _cardInfoService.GetAllCardsD();
            

            return Ok(allUserCards);


        }
        [HttpGet("CardNumber")]
        public ActionResult<UserCardsDto> GetbyNumberOfCard(string CardNumber)
        {
            var GetWithNumber = _cardInfoService.GetCardbyNumberD(CardNumber);
            return Ok(GetWithNumber);

        }

        [HttpPost]

        public ActionResult<UserCardsDto> CreateCard([FromBody] GenerateCardOptionsDto generateCard)
        {

            var createCard = _cardInfoService.CrateNewCardD(generateCard);


            if (createCard == null)
            {
                return BadRequest();

            }

            return Ok(createCard);

        }

       
    }
}
