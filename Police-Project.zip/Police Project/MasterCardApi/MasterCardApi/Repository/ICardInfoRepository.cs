﻿using MasterCardApi.Dtos;
using MasterCardApi.Entities;
using Microsoft.Identity.Client;

namespace MasterCardApi.Repository
{
    public interface ICardInfoRepository
    {

        IEnumerable<UserCards> GetAllCards();
        UserCards CrateNewCard (UserCards userCards);
        UserCards GetCardbyNumber(string CardNumber);

        void Transaction(string CardNumber, decimal NewBalance);

    }
}
