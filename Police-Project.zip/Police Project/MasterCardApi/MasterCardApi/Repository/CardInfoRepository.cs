﻿using MasterCardApi.Dtos;
using MasterCardApi.Entities;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query.Internal;
using System.Text.RegularExpressions;

namespace MasterCardApi.Repository
{
    public class CardInfoRepository : ICardInfoRepository
    {
        private readonly PaymentContext _context;
        public CardInfoRepository(PaymentContext context)
        {

            _context = context;

        }

        public UserCards CrateNewCard(UserCards userCards)
        {
            var saved = _context.UserCards.Add(userCards);
            _context.SaveChanges();
            return userCards;

        }

        public  IEnumerable<UserCards> GetAllCards()
        {
            
            return  _context.UserCards.ToList();

        }

        public UserCards GetCardbyNumber(string CardNumber)
        {
            var card = _context.UserCards.FirstOrDefault(x => x.CardNumber == CardNumber);
            //if(card.Isnullor)
            return card;
        }


        public void Transaction(string CardNumber, decimal newBalance)
        {
            var user = _context.UserCards.FirstOrDefault(x => x.CardNumber == CardNumber); // Assuming you have logic to get the user
            if (user != null)
            {
                user.Balance = newBalance;
                _context.SaveChanges();
            }
        }

    }
}
