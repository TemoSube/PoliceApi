﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion.Internal;
using Newtonsoft.Json;
using System.Runtime.ExceptionServices;

namespace MasterCardApi.Entities
{
    public class UserCards
    {
        public int Id { get; set; }
        public string Firstname { get; set; }
        public string LastName { get; set; }

        public string FullName { get; set; }
      
        public string CardNumber { get; set; }
        
        public string CardData { get;  set; }

        public string HideCode { get;  set; }

        public string Email { get; set; }

        public decimal Balance { get; set; }


    }
    
}
