﻿using AutoMapper;
using MasterCardApi.Dtos;
using MasterCardApi.Entities;
using MasterCardApi.Repository;

namespace MasterCardApi.Services
{
    public class CardInfoService : ICardInfoService
    {
        private readonly IMapper _mapper;
        private readonly ICardInfoRepository _cardInfoRepository;
        public CardInfoService(IMapper mapper, ICardInfoRepository cardInfoRepository)
        {
            _mapper = mapper;
            _cardInfoRepository = cardInfoRepository;


        }

        public UserCardsDto CrateNewCardD(GenerateCardOptionsDto generateCard)
        {
            //var Usercard = _mapper.Map<UserCards>(userCardsDto);
            //Usercard =  _cardInfoRepository.CrateNewCard(Usercard);
            //return _mapper.Map<UserCardsDto>(Usercard);

           
            
                // Generate fullName from firstName and lastName
                string fullName = $"{generateCard.FirstName} {generateCard.LastName}";

                // Generate cardNumber, cardData, and hideCode
                string cardNumber = GenerateCardNumber();
                string cardData = GenerateCardData();
                string hideCode = GenerateHideCode();

                // Create the entity object
                var userEntity = new UserCards
                {
                    Firstname = generateCard.FirstName,
                    LastName = generateCard.LastName,
                    FullName = fullName,
                    CardNumber = cardNumber,
                    CardData = cardData,
                    HideCode = hideCode,
                    Email = generateCard.Email

                };

            
            var postedinfo = _cardInfoRepository.CrateNewCard(userEntity);
            
            return _mapper.Map<UserCardsDto>(postedinfo);
            }

            // Method to generate a random card number
            private string GenerateCardNumber()
            {
                Random random = new Random();
                string cardNumber = "";
                for (int i = 0; i < 16; i++)
                {
                    cardNumber += random.Next(0, 10);
                    if ((i + 1) % 4 == 0 && i != 15)
                    {
                        cardNumber += " ";
                    }
                }
                return cardNumber;
            }

            // Method to generate random card data (e.g., expiry date)
            private string GenerateCardData()
            {
                Random random = new Random();
                int month = random.Next(1, 13); // Random month (1-12)
                int year = random.Next(DateTime.Today.Year, DateTime.Today.Year + 5); // Random year (current year to 5 years ahead)
                return $"{month:D2}/{year % 100:D2}";
            }

           
            private string GenerateHideCode()
            {
                Random random = new Random();
                return random.Next(1000, 10000).ToString(); 
            }

        
        public IEnumerable<UserCardsDto> GetAllCardsD()
        {
            var allcards = _cardInfoRepository.GetAllCards();

            return _mapper.Map<IEnumerable<UserCardsDto>>(allcards);//_mapper.Map<IEnumerable<UserCardsDto>>(allcards);
        }

        public UserCardsDto GetCardbyNumberD(string CardNumber)
        {
            
            var UserCard = _cardInfoRepository.GetCardbyNumber(CardNumber);
            return _mapper.Map<UserCardsDto>(UserCard);

        }

    }
}
