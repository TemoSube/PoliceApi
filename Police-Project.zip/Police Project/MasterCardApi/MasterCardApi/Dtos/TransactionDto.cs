﻿namespace MasterCardApi.Dtos
{
    public class TransactionDto
    {

        public string CardNumber { get; set; }

        public string CardData { get; set; }

        public string HideCode { get; set; }

        public decimal Balance { get; set; }
       

    }
}
