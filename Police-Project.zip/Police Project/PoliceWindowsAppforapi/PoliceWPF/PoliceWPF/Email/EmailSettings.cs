﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PoliceWPF.Email
{
    internal class EmailSettings
    {


        public string Email = "temosulaberidze40@gmail.com";
        public string Password = "ommm byke zvhc lvoj";
        public string Host = "smtp.gmail.com";
        public string DisplayName = "Police Police";
        public int Port = 587;
  
}
}

