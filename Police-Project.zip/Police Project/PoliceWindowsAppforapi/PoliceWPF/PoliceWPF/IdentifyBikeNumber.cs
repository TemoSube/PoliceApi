﻿using Microsoft.IdentityModel.Tokens;
using PoliceWPF.deserializeandserialize;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.DirectoryServices.ActiveDirectory;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PoliceWPF
{
    public partial class IdentifyBikeNumber : Form
    {
        public IdentifyBikeNumber()
        {
            InitializeComponent();
        }

        private async void btnGetBikeNumber_Click(object sender, EventArgs e)
        {
            
                string Url = "http://localhost:5022/";
                string BikeNumber = txtBikeNumber.Text;
                string pattern = @"^[A-Z]{2}-\d{4}$";
            try
            {
                if (BikeNumber.IsNullOrEmpty())
                {
                    MessageBox.Show("Gtxovt Sheavsot BikeNumber Veli");

                }
                else if (!Regex.IsMatch(BikeNumber, pattern))
                {

                    MessageBox.Show("Gtxovt Sheavsot BikeNumber Veli amgvarad LL-000-LL");

                }
                else
                {

                    comunication GetBikeUrl = new comunication(Url);
                    var BikeInfo = await GetBikeUrl.GetBikeWithNumber(BikeNumber);
                    richResponseB.Text = comunication.BeutyfyJson(BikeInfo);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("resursi ar moidzebna");
            }

        }
    }
}
