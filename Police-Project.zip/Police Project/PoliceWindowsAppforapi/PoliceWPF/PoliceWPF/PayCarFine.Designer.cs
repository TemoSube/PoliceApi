﻿namespace PoliceWPF
{
    partial class PayCarFine
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            richTextForCarFine = new RichTextBox();
            btnGetCarFine = new Button();
            txtCarCheckNumber = new TextBox();
            txtCarNumberFine = new TextBox();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txtHideCode = new TextBox();
            txtDate = new TextBox();
            txtCardNumber = new TextBox();
            pictureBox2 = new PictureBox();
            button1 = new Button();
            pictureBox1 = new PictureBox();
            label4 = new Label();
            label5 = new Label();
            TxtCodeGetter = new TextBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // richTextForCarFine
            // 
            richTextForCarFine.Location = new Point(31, 142);
            richTextForCarFine.Name = "richTextForCarFine";
            richTextForCarFine.Size = new Size(310, 284);
            richTextForCarFine.TabIndex = 7;
            richTextForCarFine.Text = "";
            // 
            // btnGetCarFine
            // 
            btnGetCarFine.Location = new Point(31, 14);
            btnGetCarFine.Name = "btnGetCarFine";
            btnGetCarFine.Size = new Size(159, 48);
            btnGetCarFine.TabIndex = 6;
            btnGetCarFine.Text = "GetCarFine";
            btnGetCarFine.UseVisualStyleBackColor = true;
            btnGetCarFine.Click += btnGetCarFine_Click;
            // 
            // txtCarCheckNumber
            // 
            txtCarCheckNumber.Location = new Point(203, 87);
            txtCarCheckNumber.Name = "txtCarCheckNumber";
            txtCarCheckNumber.Size = new Size(138, 23);
            txtCarCheckNumber.TabIndex = 5;
            // 
            // txtCarNumberFine
            // 
            txtCarNumberFine.Location = new Point(31, 87);
            txtCarNumberFine.Name = "txtCarNumberFine";
            txtCarNumberFine.Size = new Size(149, 23);
            txtCarNumberFine.TabIndex = 4;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(596, 154);
            label3.Name = "label3";
            label3.Size = new Size(29, 15);
            label3.TabIndex = 23;
            label3.Text = "CVV";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(436, 154);
            label2.Name = "label2";
            label2.Size = new Size(48, 15);
            label2.TabIndex = 22;
            label2.Text = "MM/YY";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(436, 90);
            label1.Name = "label1";
            label1.Size = new Size(79, 15);
            label1.TabIndex = 21;
            label1.Text = "Card Number";
            // 
            // txtHideCode
            // 
            txtHideCode.Location = new Point(596, 172);
            txtHideCode.Name = "txtHideCode";
            txtHideCode.Size = new Size(65, 23);
            txtHideCode.TabIndex = 20;
            // 
            // txtDate
            // 
            txtDate.Location = new Point(436, 172);
            txtDate.Name = "txtDate";
            txtDate.Size = new Size(96, 23);
            txtDate.TabIndex = 19;
            // 
            // txtCardNumber
            // 
            txtCardNumber.Location = new Point(436, 109);
            txtCardNumber.Name = "txtCardNumber";
            txtCardNumber.Size = new Size(274, 23);
            txtCardNumber.TabIndex = 18;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.MasterCard;
            pictureBox2.Location = new Point(436, 39);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(56, 37);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 17;
            pictureBox2.TabStop = false;
            // 
            // button1
            // 
            button1.Location = new Point(512, 289);
            button1.Name = "button1";
            button1.Size = new Size(137, 36);
            button1.TabIndex = 16;
            button1.Text = "Pay";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.white_Photo;
            pictureBox1.Location = new Point(422, 27);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(300, 205);
            pictureBox1.TabIndex = 15;
            pictureBox1.TabStop = false;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(31, 69);
            label4.Name = "label4";
            label4.Size = new Size(69, 15);
            label4.TabIndex = 24;
            label4.Text = "CarNumber";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(203, 69);
            label5.Name = "label5";
            label5.Size = new Size(84, 15);
            label5.TabIndex = 25;
            label5.Text = "CheckNumber";
            // 
            // TxtCodeGetter
            // 
            TxtCodeGetter.Location = new Point(491, 247);
            TxtCodeGetter.Name = "TxtCodeGetter";
            TxtCodeGetter.Size = new Size(170, 23);
            TxtCodeGetter.TabIndex = 26;
            // 
            // PayCarFine
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(752, 450);
            Controls.Add(TxtCodeGetter);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtHideCode);
            Controls.Add(txtDate);
            Controls.Add(txtCardNumber);
            Controls.Add(pictureBox2);
            Controls.Add(button1);
            Controls.Add(pictureBox1);
            Controls.Add(richTextForCarFine);
            Controls.Add(btnGetCarFine);
            Controls.Add(txtCarCheckNumber);
            Controls.Add(txtCarNumberFine);
            FormBorderStyle = FormBorderStyle.None;
            Name = "PayCarFine";
            Text = "PayCarFine";
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private RichTextBox richTextForCarFine;
        private Button btnGetCarFine;
        private TextBox txtCarCheckNumber;
        private TextBox txtCarNumberFine;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtHideCode;
        private TextBox txtDate;
        private TextBox txtCardNumber;
        private PictureBox pictureBox2;
        private Button button1;
        private PictureBox pictureBox1;
        private Label label4;
        private Label label5;
        private TextBox TxtCodeGetter;
    }
}