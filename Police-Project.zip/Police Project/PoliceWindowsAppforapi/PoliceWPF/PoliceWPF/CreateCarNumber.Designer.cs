﻿namespace PoliceWPF
{
    partial class CreateCarNumber
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtCarNumber = new TextBox();
            txtFirstName = new TextBox();
            txtLastName = new TextBox();
            txtPhoneNumber = new TextBox();
            txtPersonalNumber = new TextBox();
            txtAddress = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            button1 = new Button();
            label7 = new Label();
            SuspendLayout();
            // 
            // txtCarNumber
            // 
            txtCarNumber.Location = new Point(178, 67);
            txtCarNumber.Name = "txtCarNumber";
            txtCarNumber.Size = new Size(170, 23);
            txtCarNumber.TabIndex = 0;
            // 
            // txtFirstName
            // 
            txtFirstName.Location = new Point(178, 164);
            txtFirstName.Name = "txtFirstName";
            txtFirstName.Size = new Size(170, 23);
            txtFirstName.TabIndex = 1;
            // 
            // txtLastName
            // 
            txtLastName.Location = new Point(535, 164);
            txtLastName.Name = "txtLastName";
            txtLastName.Size = new Size(170, 23);
            txtLastName.TabIndex = 2;
            // 
            // txtPhoneNumber
            // 
            txtPhoneNumber.Location = new Point(178, 257);
            txtPhoneNumber.Name = "txtPhoneNumber";
            txtPhoneNumber.Size = new Size(170, 23);
            txtPhoneNumber.TabIndex = 3;
            // 
            // txtPersonalNumber
            // 
            txtPersonalNumber.Location = new Point(535, 257);
            txtPersonalNumber.Name = "txtPersonalNumber";
            txtPersonalNumber.Size = new Size(170, 23);
            txtPersonalNumber.TabIndex = 4;
            // 
            // txtAddress
            // 
            txtAddress.Location = new Point(535, 68);
            txtAddress.Name = "txtAddress";
            txtAddress.Size = new Size(170, 23);
            txtAddress.TabIndex = 5;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold | FontStyle.Italic);
            label1.Location = new Point(54, 163);
            label1.Name = "label1";
            label1.Size = new Size(80, 20);
            label1.TabIndex = 7;
            label1.Text = "FirstName";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold | FontStyle.Italic);
            label2.Location = new Point(409, 163);
            label2.Name = "label2";
            label2.Size = new Size(78, 20);
            label2.TabIndex = 8;
            label2.Text = "LastName";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold | FontStyle.Italic);
            label3.Location = new Point(48, 256);
            label3.Name = "label3";
            label3.Size = new Size(109, 20);
            label3.TabIndex = 9;
            label3.Text = "PhoneNumber";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold | FontStyle.Italic);
            label4.Location = new Point(405, 257);
            label4.Name = "label4";
            label4.Size = new Size(125, 20);
            label4.TabIndex = 10;
            label4.Text = "PersonalNumber";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold | FontStyle.Italic);
            label5.Location = new Point(411, 67);
            label5.Name = "label5";
            label5.Size = new Size(63, 20);
            label5.TabIndex = 11;
            label5.Text = "Address";
            // 
            // button1
            // 
            button1.Location = new Point(334, 408);
            button1.Name = "button1";
            button1.Size = new Size(211, 34);
            button1.TabIndex = 12;
            button1.Text = "Create";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold | FontStyle.Italic);
            label7.Location = new Point(54, 67);
            label7.Name = "label7";
            label7.Size = new Size(91, 20);
            label7.TabIndex = 15;
            label7.Text = "CarNumber";
            // 
            // CreateCarNumber
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(946, 469);
            Controls.Add(label7);
            Controls.Add(button1);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtAddress);
            Controls.Add(txtPersonalNumber);
            Controls.Add(txtPhoneNumber);
            Controls.Add(txtLastName);
            Controls.Add(txtFirstName);
            Controls.Add(txtCarNumber);
            FormBorderStyle = FormBorderStyle.None;
            Name = "CreateCarNumber";
            Text = "CreateCarNumber";
            Load += CreateCarNumber_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtCarNumber;
        private TextBox txtFirstName;
        private TextBox txtLastName;
        private TextBox txtPhoneNumber;
        private TextBox txtPersonalNumber;
        private TextBox txtAddress;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Button button1;
        private Label label7;
    }
}