﻿namespace PoliceWPF
{
    partial class PayBikeFine
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtBikeNumberFine = new TextBox();
            txtBikeCheckNumber = new TextBox();
            btnGetBikeFine = new Button();
            richTextForBikeFine = new RichTextBox();
            pictureBox1 = new PictureBox();
            button1 = new Button();
            pictureBox2 = new PictureBox();
            txtCardNumber = new TextBox();
            txtDate = new TextBox();
            txtHideCode = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            TxtCodesGetter = new TextBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // txtBikeNumberFine
            // 
            txtBikeNumberFine.Location = new Point(30, 94);
            txtBikeNumberFine.Name = "txtBikeNumberFine";
            txtBikeNumberFine.Size = new Size(141, 23);
            txtBikeNumberFine.TabIndex = 0;
            // 
            // txtBikeCheckNumber
            // 
            txtBikeCheckNumber.Location = new Point(216, 94);
            txtBikeCheckNumber.Name = "txtBikeCheckNumber";
            txtBikeCheckNumber.Size = new Size(139, 23);
            txtBikeCheckNumber.TabIndex = 1;
            // 
            // btnGetBikeFine
            // 
            btnGetBikeFine.Location = new Point(30, 12);
            btnGetBikeFine.Name = "btnGetBikeFine";
            btnGetBikeFine.Size = new Size(159, 48);
            btnGetBikeFine.TabIndex = 2;
            btnGetBikeFine.Text = "GetBikeFine";
            btnGetBikeFine.UseVisualStyleBackColor = true;
            btnGetBikeFine.Click += btnGetBikeFine_Click;
            // 
            // richTextForBikeFine
            // 
            richTextForBikeFine.Location = new Point(30, 136);
            richTextForBikeFine.Name = "richTextForBikeFine";
            richTextForBikeFine.Size = new Size(325, 290);
            richTextForBikeFine.TabIndex = 3;
            richTextForBikeFine.Text = "";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.white_Photo;
            pictureBox1.Location = new Point(428, 22);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(300, 205);
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // button1
            // 
            button1.Location = new Point(513, 282);
            button1.Name = "button1";
            button1.Size = new Size(137, 36);
            button1.TabIndex = 7;
            button1.Text = "Pay";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.MasterCard;
            pictureBox2.Location = new Point(442, 34);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(56, 37);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 8;
            pictureBox2.TabStop = false;
            // 
            // txtCardNumber
            // 
            txtCardNumber.Location = new Point(442, 104);
            txtCardNumber.Name = "txtCardNumber";
            txtCardNumber.Size = new Size(274, 23);
            txtCardNumber.TabIndex = 9;
            // 
            // txtDate
            // 
            txtDate.Location = new Point(442, 167);
            txtDate.Name = "txtDate";
            txtDate.Size = new Size(96, 23);
            txtDate.TabIndex = 10;
            // 
            // txtHideCode
            // 
            txtHideCode.Location = new Point(602, 167);
            txtHideCode.Name = "txtHideCode";
            txtHideCode.Size = new Size(65, 23);
            txtHideCode.TabIndex = 11;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(442, 85);
            label1.Name = "label1";
            label1.Size = new Size(79, 15);
            label1.TabIndex = 12;
            label1.Text = "Card Number";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(442, 149);
            label2.Name = "label2";
            label2.Size = new Size(48, 15);
            label2.TabIndex = 13;
            label2.Text = "MM/YY";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(602, 149);
            label3.Name = "label3";
            label3.Size = new Size(29, 15);
            label3.TabIndex = 14;
            label3.Text = "CVV";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(30, 76);
            label4.Name = "label4";
            label4.Size = new Size(73, 15);
            label4.TabIndex = 25;
            label4.Text = "BikeNumber";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(216, 76);
            label5.Name = "label5";
            label5.Size = new Size(84, 15);
            label5.TabIndex = 26;
            label5.Text = "CheckNumber";
            // 
            // TxtCodesGetter
            // 
            TxtCodesGetter.Location = new Point(497, 242);
            TxtCodesGetter.Name = "TxtCodesGetter";
            TxtCodesGetter.Size = new Size(170, 23);
            TxtCodesGetter.TabIndex = 27;
            // 
            // PayBikeFine
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(756, 442);
            Controls.Add(TxtCodesGetter);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtHideCode);
            Controls.Add(txtDate);
            Controls.Add(txtCardNumber);
            Controls.Add(pictureBox2);
            Controls.Add(button1);
            Controls.Add(pictureBox1);
            Controls.Add(richTextForBikeFine);
            Controls.Add(btnGetBikeFine);
            Controls.Add(txtBikeCheckNumber);
            Controls.Add(txtBikeNumberFine);
            FormBorderStyle = FormBorderStyle.None;
            Name = "PayBikeFine";
            Text = "PayBikeFine";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtBikeNumberFine;
        private TextBox txtBikeCheckNumber;
        private Button btnGetBikeFine;
        private RichTextBox richTextForBikeFine;
        private PictureBox pictureBox1;
        private Button button1;
        private PictureBox pictureBox2;
        private TextBox txtCardNumber;
        private TextBox txtDate;
        private TextBox txtHideCode;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox TxtCodesGetter;
    }
}