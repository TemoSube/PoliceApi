﻿namespace PoliceWPF
{
    partial class CitizenMainWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CitizenMainWindow));
            panelSide = new Panel();
            pictureBox1 = new PictureBox();
            btnPayBikeFine = new Button();
            btnPayCarFine = new Button();
            MainPanel = new Panel();
            BTNclose = new Button();
            panelHeader = new Panel();
            panelSide.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panelHeader.SuspendLayout();
            SuspendLayout();
            // 
            // panelSide
            // 
            panelSide.BackColor = SystemColors.ControlDarkDark;
            panelSide.Controls.Add(pictureBox1);
            panelSide.Controls.Add(btnPayBikeFine);
            panelSide.Controls.Add(btnPayCarFine);
            panelSide.Dock = DockStyle.Left;
            panelSide.Location = new Point(0, 0);
            panelSide.Name = "panelSide";
            panelSide.Size = new Size(200, 471);
            panelSide.TabIndex = 1;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(53, 6);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(88, 86);
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // btnPayBikeFine
            // 
            btnPayBikeFine.BackColor = SystemColors.ControlDarkDark;
            btnPayBikeFine.FlatStyle = FlatStyle.Flat;
            btnPayBikeFine.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnPayBikeFine.ForeColor = SystemColors.Menu;
            btnPayBikeFine.Location = new Point(6, 252);
            btnPayBikeFine.Name = "btnPayBikeFine";
            btnPayBikeFine.Size = new Size(191, 35);
            btnPayBikeFine.TabIndex = 1;
            btnPayBikeFine.Text = "Paying a bike fine";
            btnPayBikeFine.UseVisualStyleBackColor = false;
            btnPayBikeFine.Click += btnIdentifyBike_Click;
            // 
            // btnPayCarFine
            // 
            btnPayCarFine.BackColor = SystemColors.ControlDarkDark;
            btnPayCarFine.FlatStyle = FlatStyle.Flat;
            btnPayCarFine.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnPayCarFine.ForeColor = SystemColors.Menu;
            btnPayCarFine.Location = new Point(6, 170);
            btnPayCarFine.Name = "btnPayCarFine";
            btnPayCarFine.Size = new Size(191, 35);
            btnPayCarFine.TabIndex = 0;
            btnPayCarFine.Text = "Paying a car fine";
            btnPayCarFine.UseVisualStyleBackColor = false;
            btnPayCarFine.Click += btnPayCarFine_Click;
            // 
            // MainPanel
            // 
            MainPanel.BorderStyle = BorderStyle.FixedSingle;
            MainPanel.Location = new Point(200, 30);
            MainPanel.Name = "MainPanel";
            MainPanel.Size = new Size(756, 442);
            MainPanel.TabIndex = 3;
            MainPanel.Paint += MainPanel_Paint;
            // 
            // BTNclose
            // 
            BTNclose.BackColor = SystemColors.ControlDarkDark;
            BTNclose.FlatAppearance.BorderSize = 0;
            BTNclose.FlatStyle = FlatStyle.Flat;
            BTNclose.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BTNclose.ForeColor = SystemColors.Menu;
            BTNclose.Location = new Point(721, 1);
            BTNclose.Name = "BTNclose";
            BTNclose.Size = new Size(35, 29);
            BTNclose.TabIndex = 5;
            BTNclose.Text = "X";
            BTNclose.UseVisualStyleBackColor = false;
            BTNclose.Click += BTNclose_Click_1;
            // 
            // panelHeader
            // 
            panelHeader.BackColor = SystemColors.ControlDarkDark;
            panelHeader.Controls.Add(BTNclose);
            panelHeader.Dock = DockStyle.Top;
            panelHeader.Location = new Point(200, 0);
            panelHeader.Name = "panelHeader";
            panelHeader.Size = new Size(754, 30);
            panelHeader.TabIndex = 4;
            // 
            // CitizenMainWindow
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(954, 471);
            Controls.Add(panelHeader);
            Controls.Add(MainPanel);
            Controls.Add(panelSide);
            FormBorderStyle = FormBorderStyle.None;
            Name = "CitizenMainWindow";
            Text = "CitizenMainWindow";
            panelSide.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panelHeader.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panelSide;
        private PictureBox pictureBox1;
        private Button btnPayBikeFine;
        private Button btnPayCarFine;
        private Panel MainPanel;
        private Button BTNclose;
        private Panel panelHeader;
    }
}