﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace PoliceWPF.deserializeandserialize
{

    public class CarFineDto
    {
        public string carNumber { get; set; }
        public decimal Amount { get; set; }
        public string Reason { get; set; }
        public string CheckNumber { get; set; }
        public string Gmail { get; set; }

        public string payStatus { get; set; }
    }

    public class BikeFineDto 
    {

        public string bikeNumber { get; set; }
        public decimal Amount { get; set; }
        public string Reason { get; set; }
        public string CheckNumber { get; set; }
        public string Gmail { get; set; }
        public string payStatus { get; set; }

    }

    public class comunication
    {

        private readonly string _baseUrl;

        public comunication(string baseUr)
        {
            _baseUrl = baseUr;
        }

        public async Task<string> GetCarWithNumber(string CarNumber)
        {

            string url = $"{_baseUrl}api/CarInfo/CarNumber?CarNumber={CarNumber}";


            using (HttpClient client = new HttpClient())
                try
                {
                    // Send a GET request
                    HttpResponseMessage response = await client.GetAsync(url);

                    // Check if the request was successful
                    if (response.IsSuccessStatusCode)
                    {
                        // Read the response content as string
                        return await response.Content.ReadAsStringAsync();
                    }
                    else
                    {
                        return $"Failed to get car information. Status code: {response.StatusCode}";
                    }
                }
                catch (Exception ex)
                {
                    return $"An error occurred: {ex.Message}";
                }
        }


        //for bike

        public async Task<string> GetBikeWithNumber(string BikeNumber)
        {

            string url = $"{_baseUrl}api/BikeInfo/BikeNumber?BikeNumber={BikeNumber}";


            using (HttpClient client = new HttpClient())
                try
                {
                    // Send a GET request
                    HttpResponseMessage response = await client.GetAsync(url);

                    // Check if the request was successful
                    if (response.IsSuccessStatusCode)
                    {
                        // Read the response content as string
                        return await response.Content.ReadAsStringAsync();
                    }
                    else
                    {
                        return $"Failed to get bike information. Status code: {response.StatusCode}";
                    }
                }
                catch (Exception ex)
                {
                    return $"An error occurred: {ex.Message}";
                }
        }


        public async Task<string> PostCarFine(CarFineDto carFineDto)
        {

            string json = JsonConvert.SerializeObject(carFineDto);

            string Url = $"{_baseUrl}/api/CarFine";

            using (HttpClient client = new HttpClient())
            {

                try
                {
                    // Create a StringContent object with JSON data
                    StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                    // Send a POST request
                    HttpResponseMessage response = await client.PostAsync(Url, content);

                    // Check if the request was successful
                    if (response.IsSuccessStatusCode)
                    {
                        // Read the response content as string
                        return await response.Content.ReadAsStringAsync();
                    }
                    else
                    {
                        return $"Failed to post car information. Status code: {response.StatusCode}";
                    }
                }
                catch (Exception ex)
                {
                    return $"An error occurred: {ex.Message}";
                }
            }
        }


        public async Task<string> PostBikeFine(BikeFineDto BikeFineDto)
        {

            var json = JsonConvert.SerializeObject(BikeFineDto);
            string Url = $"{_baseUrl}/api/BikeFine";
            using (HttpClient client = new HttpClient())
            {
                StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                HttpResponseMessage response = await client.PostAsync(Url, content);

                try
                {

                    if (response.IsSuccessStatusCode)
                    {
                        // Read the response content as string
                        return await response.Content.ReadAsStringAsync();
                    }
                    else
                    {
                        return $"Failed to post car information. Status code: {response.StatusCode}";
                    }
                }

                 catch (Exception ex)
                {
                    return $"An error occurred: {ex.Message}";
                }
            }
        }

        public async Task<string> GetBikeFine(string BikeNumber, string CheckNumber) 
        {

            string url = $"{_baseUrl}/api/BikeFine/CheckAndBikeNumber?BikeNumber={BikeNumber}&CheckNumber={CheckNumber}";

            using (HttpClient client = new HttpClient()) 
            {
                try
                {
                    HttpResponseMessage response = await client.GetAsync(url);
                    

                    if (response.IsSuccessStatusCode)
                    {

                        return await response.Content.ReadAsStringAsync();

                    }
                    else
                    {
                        return $"Failed to get car information. Status code: {response.StatusCode}";
                    }
                }

                catch (Exception ex)
                {
                    return $"An error occurred: {ex.Message}";
                }
        }
}

        public async Task<string> GetCarFine(string CarNumber, string CheckNumber)
        {

            string url = $"{_baseUrl}/api/CarFine/CheckAndCarNumber?CarNumber={CarNumber}&CheckNumber={CheckNumber}";
            using (HttpClient client = new HttpClient())
            {
                try
                {


                    HttpResponseMessage content = await client.GetAsync(url);


                    if (content.IsSuccessStatusCode)
                    {
                        return await content.Content.ReadAsStringAsync();

                    }
                   
                    else
                    {
                        return $"Failed to get car information. Status code: {content.StatusCode}";
                    }
                }
                catch (Exception ex)
                {
                    return $"An error occurred: {ex.Message}";
                }
            }
        }



            public static string BeutyfyJson(string jsonStr) 
        {
        
            JToken ParseJson = JToken.Parse(jsonStr);
            return ParseJson.ToString(Newtonsoft.Json.Formatting.Indented);
        
        }
    }
}
