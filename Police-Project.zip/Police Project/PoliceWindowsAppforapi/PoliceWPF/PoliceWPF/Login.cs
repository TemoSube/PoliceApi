﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;
using System.Net.Http.Json;
using System.Net.Http.Headers;
using Microsoft.IdentityModel.Tokens;


namespace PoliceWPF
{
    public partial class Login : Form
    {

        //private readonly AuthService _authService;
        private const string BaseUrl = "http://localhost:5022"; // Change this to your API URL
        private string _accessToken;
        private string _userRole;
        public Login()
        {
            InitializeComponent();

        }

        private async void BtnLogin_Click(object sender, EventArgs e)
        {

            string username = txtUserName.Text.Trim();
            string password = txtPassword.Text.Trim();

            using (HttpClient client = new HttpClient())
            {
                var loginData = new { UserName = username, Password = password };
                var content = new StringContent(JsonConvert.SerializeObject(loginData), Encoding.UTF8, "application/json");

                HttpResponseMessage response = await client.PostAsync($"{BaseUrl}/Auth/login", content);

                if (response.IsSuccessStatusCode)
                {
                    var responseData = await response.Content.ReadAsStringAsync();
                    Console.WriteLine("Response Data: " + responseData); // Print response data for debugging

                    var tokenAndRole = JsonConvert.DeserializeObject<LoginData>(responseData);
                    Console.WriteLine("Token and Role: " + tokenAndRole); // Print token and role for debugging

                    _accessToken = tokenAndRole.token;
                    _userRole = tokenAndRole.roleName;

                    MessageBox.Show("Login successful!");

                    Form newWindow = null;

                    // Determine user's access level based on role
                    if (string.IsNullOrEmpty(_userRole))
                    {
                        MessageBox.Show("Role not found in response data.");
                    }
                    else if (_userRole == "citizen")
                    {

                        CitizenMainWindow ForCitize = new CitizenMainWindow(_accessToken);
                        ForCitize.Show();
                        this.Hide();


                    }
                    else if (_userRole == "police")
                    {
                        PoliceMainWindow ForPolice = new PoliceMainWindow(_accessToken);
                        ForPolice.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Unknown role: " + _userRole);
                    }
                    if (newWindow != null)
                    {
                        newWindow.Show();
                        this.Hide(); // Close the login window
                    }

                }
                else
                {
                    MessageBox.Show("Invalid username or password. Please try again.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            Registration registration = new Registration();
            this.Hide();
            registration.Show();

        }
    }

    //    private async Task<string> InvokeProtectedAction(string actionUrl)
    //    {
    //        using (HttpClient client = new HttpClient())
    //        {
    //            if (string.IsNullOrEmpty(_accessToken))
    //            {
    //                MessageBox.Show("Please login first.");
    //                return null;
    //            }

    //            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _accessToken);

    //            HttpResponseMessage response = await client.GetAsync($"{BaseUrl}/{actionUrl}");

    //            if (response.IsSuccessStatusCode)
    //            {
    //                return await response.Content.ReadAsStringAsync();
    //            }
    //            else
    //            {
    //                MessageBox.Show("Error accessing API action: " + response.StatusCode);
    //                return null;
    //            }
    //        }
    //    }
    //}
}
