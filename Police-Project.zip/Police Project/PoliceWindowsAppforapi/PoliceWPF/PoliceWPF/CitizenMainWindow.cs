﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PoliceWPF
{
    public partial class CitizenMainWindow : Form
    {
        public CitizenMainWindow(object token)
        {
            InitializeComponent();
        }

        public void loadform(object form)
        {

            if (this.MainPanel.Controls.Count > 0)
                this.MainPanel.Controls.RemoveAt(0);
            Form f = form as Form;
            f.TopLevel = false;
            f.Dock = DockStyle.Fill;
            this.MainPanel.Controls.Add(f);
            this.MainPanel.Tag = f;
            f.Show();


        }

        private void btnIdentifyBike_Click(object sender, EventArgs e)
        {

            loadform(new PayBikeFine());

        }

        private void btnPayCarFine_Click(object sender, EventArgs e)
        {
            loadform(new PayCarFine());
        }

        private void BTNclose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void MainPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void BTNclose_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
