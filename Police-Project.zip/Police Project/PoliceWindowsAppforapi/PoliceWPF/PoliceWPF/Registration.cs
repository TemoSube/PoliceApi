﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PoliceWPF
{
    public partial class Registration : Form
    {
        public Registration()
        {
            InitializeComponent();
        }

        private async void button1_Click(object sender, EventArgs e)
        {

            string address = "http://localhost:5022/";

            string UserName = txtuserName.Text.Trim();
            string Password = txtpassword.Text.Trim();
            var RoleId = Convert.ToInt32(txtRole.Text);




            using (HttpClient client = new HttpClient())
            {

                var RegisterObject = new { userName = UserName, password = Password, roleId = RoleId };
                //var content = new StringContent(JsonConvert.SerializeObject(RegisterObject), Encoding.UTF8, "application/json");

                var json = JsonConvert.SerializeObject(RegisterObject);
                StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                HttpResponseMessage response = await client.PostAsync($"{address}Auth/register", content);


                if (response.IsSuccessStatusCode)
                {

                    MessageBox.Show("თქვენ წარმატებით გაიარეთ რეგისტრაცია");
                    Login login = new Login();
                    this.Hide();
                    login.Show();


                }

            }



        }

        private void OpenLogin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Login login = new Login();
            this.Hide();
            login.ShowDialog();
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
