﻿namespace PoliceWPF
{
    partial class CreateBikeNumber
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            txtAddressB = new TextBox();
            txtPersonalNumberB = new TextBox();
            txtPhoneNumberB = new TextBox();
            txtLastNameB = new TextBox();
            txtFirstNameB = new TextBox();
            txtBikeNumber = new TextBox();
            label7 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(330, 406);
            button1.Name = "button1";
            button1.Size = new Size(217, 35);
            button1.TabIndex = 25;
            button1.Text = "Create";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // txtAddressB
            // 
            txtAddressB.Location = new Point(583, 58);
            txtAddressB.Name = "txtAddressB";
            txtAddressB.Size = new Size(170, 23);
            txtAddressB.TabIndex = 18;
            // 
            // txtPersonalNumberB
            // 
            txtPersonalNumberB.Location = new Point(583, 236);
            txtPersonalNumberB.Name = "txtPersonalNumberB";
            txtPersonalNumberB.Size = new Size(170, 23);
            txtPersonalNumberB.TabIndex = 17;
            // 
            // txtPhoneNumberB
            // 
            txtPhoneNumberB.Location = new Point(199, 232);
            txtPhoneNumberB.Name = "txtPhoneNumberB";
            txtPhoneNumberB.Size = new Size(170, 23);
            txtPhoneNumberB.TabIndex = 16;
            // 
            // txtLastNameB
            // 
            txtLastNameB.Location = new Point(583, 142);
            txtLastNameB.Name = "txtLastNameB";
            txtLastNameB.Size = new Size(170, 23);
            txtLastNameB.TabIndex = 15;
            // 
            // txtFirstNameB
            // 
            txtFirstNameB.Location = new Point(199, 138);
            txtFirstNameB.Name = "txtFirstNameB";
            txtFirstNameB.Size = new Size(170, 23);
            txtFirstNameB.TabIndex = 14;
            // 
            // txtBikeNumber
            // 
            txtBikeNumber.Location = new Point(199, 58);
            txtBikeNumber.Name = "txtBikeNumber";
            txtBikeNumber.Size = new Size(170, 23);
            txtBikeNumber.TabIndex = 13;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold | FontStyle.Italic);
            label7.Location = new Point(38, 61);
            label7.Name = "label7";
            label7.Size = new Size(95, 20);
            label7.TabIndex = 32;
            label7.Text = "BikeNumber";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold | FontStyle.Italic);
            label5.Location = new Point(422, 61);
            label5.Name = "label5";
            label5.Size = new Size(63, 20);
            label5.TabIndex = 31;
            label5.Text = "Address";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold | FontStyle.Italic);
            label4.Location = new Point(422, 239);
            label4.Name = "label4";
            label4.Size = new Size(125, 20);
            label4.TabIndex = 30;
            label4.Text = "PersonalNumber";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold | FontStyle.Italic);
            label3.Location = new Point(38, 235);
            label3.Name = "label3";
            label3.Size = new Size(109, 20);
            label3.TabIndex = 29;
            label3.Text = "PhoneNumber";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold | FontStyle.Italic);
            label2.Location = new Point(426, 145);
            label2.Name = "label2";
            label2.Size = new Size(78, 20);
            label2.TabIndex = 28;
            label2.Text = "LastName";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold | FontStyle.Italic);
            label1.Location = new Point(42, 141);
            label1.Name = "label1";
            label1.Size = new Size(80, 20);
            label1.TabIndex = 27;
            label1.Text = "FirstName";
            // 
            // CreateBikeNumber
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(953, 472);
            Controls.Add(label7);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button1);
            Controls.Add(txtAddressB);
            Controls.Add(txtPersonalNumberB);
            Controls.Add(txtPhoneNumberB);
            Controls.Add(txtLastNameB);
            Controls.Add(txtFirstNameB);
            Controls.Add(txtBikeNumber);
            FormBorderStyle = FormBorderStyle.None;
            Name = "CreateBikeNumber";
            Text = "CreateBikeNumber";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private TextBox txtAddressB;
        private TextBox txtPersonalNumberB;
        private TextBox txtPhoneNumberB;
        private TextBox txtLastNameB;
        private TextBox txtFirstNameB;
        private TextBox txtBikeNumber;
        private Label label7;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
    }
}