﻿namespace PoliceWPF
{
    partial class CarFine
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtCarNumberF = new TextBox();
            label1 = new Label();
            lbl = new Label();
            lblAmount = new Label();
            txtGmail = new TextBox();
            txtAmount = new TextBox();
            label2 = new Label();
            txtReason = new TextBox();
            btnCreate = new Button();
            label3 = new Label();
            txtPayStatus = new TextBox();
            SuspendLayout();
            // 
            // txtCarNumberF
            // 
            txtCarNumberF.Location = new Point(137, 63);
            txtCarNumberF.Name = "txtCarNumberF";
            txtCarNumberF.Size = new Size(140, 23);
            txtCarNumberF.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(62, 71);
            label1.Name = "label1";
            label1.Size = new Size(69, 15);
            label1.TabIndex = 2;
            label1.Text = "CarNumber";
            // 
            // lbl
            // 
            lbl.AutoSize = true;
            lbl.Location = new Point(358, 152);
            lbl.Name = "lbl";
            lbl.Size = new Size(38, 15);
            lbl.TabIndex = 7;
            lbl.Text = "Gmail";
            // 
            // lblAmount
            // 
            lblAmount.AutoSize = true;
            lblAmount.Location = new Point(358, 71);
            lblAmount.Name = "lblAmount";
            lblAmount.Size = new Size(51, 15);
            lblAmount.TabIndex = 6;
            lblAmount.Text = "Amount";
            // 
            // txtGmail
            // 
            txtGmail.Location = new Point(445, 144);
            txtGmail.Name = "txtGmail";
            txtGmail.Size = new Size(140, 23);
            txtGmail.TabIndex = 5;
            // 
            // txtAmount
            // 
            txtAmount.Location = new Point(445, 63);
            txtAmount.Name = "txtAmount";
            txtAmount.Size = new Size(140, 23);
            txtAmount.TabIndex = 4;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(62, 152);
            label2.Name = "label2";
            label2.Size = new Size(45, 15);
            label2.TabIndex = 9;
            label2.Text = "Reason";
            // 
            // txtReason
            // 
            txtReason.Location = new Point(129, 144);
            txtReason.Name = "txtReason";
            txtReason.Size = new Size(140, 23);
            txtReason.TabIndex = 8;
            // 
            // btnCreate
            // 
            btnCreate.Location = new Point(294, 334);
            btnCreate.Name = "btnCreate";
            btnCreate.Size = new Size(145, 36);
            btnCreate.TabIndex = 10;
            btnCreate.Text = "Create";
            btnCreate.UseVisualStyleBackColor = true;
            btnCreate.Click += btnCreate_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(253, 234);
            label3.Name = "label3";
            label3.Size = new Size(58, 15);
            label3.TabIndex = 12;
            label3.Text = "PayStatus";
            // 
            // txtPayStatus
            // 
            txtPayStatus.Location = new Point(346, 231);
            txtPayStatus.Name = "txtPayStatus";
            txtPayStatus.Size = new Size(140, 23);
            txtPayStatus.TabIndex = 11;
            // 
            // CarFine
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label3);
            Controls.Add(txtPayStatus);
            Controls.Add(btnCreate);
            Controls.Add(label2);
            Controls.Add(txtReason);
            Controls.Add(lbl);
            Controls.Add(lblAmount);
            Controls.Add(txtGmail);
            Controls.Add(txtAmount);
            Controls.Add(label1);
            Controls.Add(txtCarNumberF);
            FormBorderStyle = FormBorderStyle.None;
            Name = "CarFine";
            Text = "CarFine";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtCarNumberF;
        private Label label1;
        private Label lbl;
        private Label lblAmount;
        private TextBox txtGmail;
        private TextBox txtAmount;
        private Label label2;
        private TextBox txtReason;
        private Button btnCreate;
        private Label label3;
        private TextBox txtPayStatus;
    }
}