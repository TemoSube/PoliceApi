﻿namespace PoliceWPF
{
    partial class IdentifyBikeNumber
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            richResponseB = new RichTextBox();
            txtBikeNumber = new TextBox();
            btnGetBikeNumber = new Button();
            SuspendLayout();
            // 
            // richResponseB
            // 
            richResponseB.Location = new Point(4, 117);
            richResponseB.Name = "richResponseB";
            richResponseB.Size = new Size(730, 321);
            richResponseB.TabIndex = 6;
            richResponseB.Text = "";
            // 
            // txtBikeNumber
            // 
            txtBikeNumber.Location = new Point(339, 51);
            txtBikeNumber.Name = "txtBikeNumber";
            txtBikeNumber.Size = new Size(208, 23);
            txtBikeNumber.TabIndex = 5;
            // 
            // btnGetBikeNumber
            // 
            btnGetBikeNumber.Location = new Point(163, 43);
            btnGetBikeNumber.Name = "btnGetBikeNumber";
            btnGetBikeNumber.Size = new Size(140, 37);
            btnGetBikeNumber.TabIndex = 4;
            btnGetBikeNumber.Text = "GetBikeNumber";
            btnGetBikeNumber.UseVisualStyleBackColor = true;
            btnGetBikeNumber.Click += btnGetBikeNumber_Click;
            // 
            // IdentifyBikeNumber
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(746, 450);
            Controls.Add(richResponseB);
            Controls.Add(txtBikeNumber);
            Controls.Add(btnGetBikeNumber);
            FormBorderStyle = FormBorderStyle.None;
            Name = "IdentifyBikeNumber";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "IdentifyBikeNumber";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private RichTextBox richResponseB;
        private TextBox txtBikeNumber;
        private Button btnGetBikeNumber;
    }
}