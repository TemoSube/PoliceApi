﻿using Microsoft.IdentityModel.Tokens;
using PoliceWPF.Dtos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PoliceWPF
{
    public partial class CreateCarNumber : Form
    {
        public CreateCarNumber()
        {
            InitializeComponent();
        }

        private async void button1_Click(object sender, EventArgs e)
        {

            string Url = "http://localhost:5022/api/CarInfo";
            string pattern = @"^[A-Z]{2}-\d{3}-[A-Z]{2}$";


            string CarNumber = txtCarNumber.Text;
            string firstName = txtFirstName.Text;
            string lastName = txtLastName.Text;
            string phoneNumber = txtPhoneNumber.Text;
            string personalNumber = txtPersonalNumber.Text;
            string address = txtAddress.Text;

            //string CarNumbesr = txtCarNumber.Text;


            using (HttpClient client = new HttpClient())
            {
                try
                {
                    if (CarNumber.IsNullOrEmpty())
                    {
                        MessageBox.Show("gtxovt Sheavsot CarNumber Veli");


                    }
                    else if (!Regex.IsMatch(CarNumber, pattern))
                    {

                        MessageBox.Show("gtxovt sheiyvanot CarNumber amgvarad LL-2354-LL ");

                    }
                    else if (firstName.IsNullOrEmpty())
                    {

                        MessageBox.Show("Gtxovt Sheavsot firstName Veli ");

                    }
                    else if (lastName.IsNullOrEmpty())
                    {

                        MessageBox.Show("Gtxovt Sheavsot lastName Veli ");

                    }
                    else if (phoneNumber.IsNullOrEmpty())
                    {

                        MessageBox.Show("Gtxovt Sheavsot phoneNumber Veli ");

                    }
                    else if (phoneNumber.Length != 9)
                    {
                        MessageBox.Show("gtxovt sheiyvanot phoneNumber swored");
                    }

                    else if (personalNumber.IsNullOrEmpty())
                    {

                        MessageBox.Show("Gtxovt Sheavsot personalNumber Veli ");
                    }
                    else if (personalNumber.Length != 11)
                    {
                        MessageBox.Show("gtxovt sheiyvanot personalNumber Veli sworad");
                    }
                    else if (address.IsNullOrEmpty())
                    {

                        MessageBox.Show("Gtxovt Sheavsot FullName Veli ");

                    }
                    else
                    {
                        MessageBox.Show("Manqanis nomeri warmatebit daemata");

                        var createcarnumber = new CreatecarNumber()
                        {
                            carNumber = CarNumber,
                            fullName = /*FullName*/ firstName + " " + lastName,
                            firstName = firstName,
                            lastName = lastName,
                            phoneNumber = Convert.ToInt64(phoneNumber),
                            personalNumber = Convert.ToInt64(personalNumber),
                            address = address


                        };

                        HttpResponseMessage response = await client.PostAsync(Url, new StringContent(JsonSerializer.Serialize(createcarnumber), Encoding.UTF8, "application/json"));
                        response.EnsureSuccessStatusCode();
                    }
                }
                catch (Exception ex)
                {

                    MessageBox.Show("resursi ar moidzebna");

                }

            }

        }

        private void CarNumber_Click(object sender, EventArgs e)
        {

        }

        private void CreateCarNumber_Load(object sender, EventArgs e)
        {

        }
    }
}
