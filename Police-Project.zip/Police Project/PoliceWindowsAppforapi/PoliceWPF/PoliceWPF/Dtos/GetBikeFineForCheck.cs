﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PoliceWPF.Dtos
{
    internal class GetBikeFineForCheck
    {


        public string bikeNumber { get; set; }
        public decimal amount { get; set; }
        public string reason { get; set; }

        public string checkNumber { get; set; }
        public string gmail { get; set; }

        public string payStatus { get; set; }

    }
}
