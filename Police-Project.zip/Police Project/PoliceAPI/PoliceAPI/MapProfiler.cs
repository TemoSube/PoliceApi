﻿using AutoMapper;
using PoliceAPI.Dtos;
using PoliceAPI.Entities;

namespace PoliceAPI
{
    public class MapProfiler : Profile
    {

        public MapProfiler()
        {

            CreateMap<CarInfo, CarInfoDto>().ReverseMap();
            CreateMap<User, UserRegisterDto>().ReverseMap();
            CreateMap<BikeInfo, BikeInfoDto>().ReverseMap();
            CreateMap<BikeFine, BikeFineDto>().ReverseMap();
            CreateMap<CarFine, CarFineDto>().ReverseMap();
            CreateMap<BikeFine,PayAndStatusForBikeDto>().ReverseMap();



        }


    }
}
