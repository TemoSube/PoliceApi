﻿namespace PoliceAPI.Dtos
{
    public class BikeFineDto
    {
        public string BikeNumber { get; set; }
        public decimal Amount { get; set; }
        public string Reason { get; set; }

        public string CheckNumber { get; set; }

       public string Gmail { get; set; }

        public string PayStatus { get; set; }
    }
}
