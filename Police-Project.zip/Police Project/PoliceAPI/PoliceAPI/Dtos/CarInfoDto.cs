﻿namespace PoliceAPI.Dtos
{
    public class CarInfoDto
    {

        //public int Id { get; set; }


        public string CarNumber { get; set; }

        public string FullName { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }


        public long  PhoneNumber { get; set; }


        public long PersonalNumber { get; set; }


        public string Address { get; set; }

    }
}
