﻿namespace PoliceAPI.Dtos
{
    public class PayAndStatusForCarDto
    {
        public string PayStatus { get; set; }

    }
}
