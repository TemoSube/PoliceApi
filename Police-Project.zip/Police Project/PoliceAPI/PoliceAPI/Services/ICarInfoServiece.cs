﻿using PoliceAPI.Dtos;

namespace PoliceAPI.Services
{
    public interface ICarInfoServiece
    {
        IEnumerable<CarInfoDto> GetAllCarInformation();

        CarInfoDto GetCarInfoByCarNumber(string CarNumber);

        CarInfoDto AddCarInfo(CarInfoDto carInfoDto);

        void UpdateCarInfo (CarInfoDto carInfoDto);



    }
}
