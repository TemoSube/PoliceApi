﻿using AutoMapper;
using PoliceAPI.Dtos;
using PoliceAPI.Entities;
using PoliceAPI.Repositories;

namespace PoliceAPI.Services
{
    public class CarFineServices : ICarFineService
    {

        private readonly ICarFineRepository _carFineRepository;
        private readonly IMapper _mapper;
        public CarFineServices(ICarFineRepository carFineRepository, IMapper mapper)
        {
            _carFineRepository = carFineRepository;
            _mapper = mapper;


        }


        public async Task<CarFineDto> AddFineOnCar(CarFineDto carFineDto)
        {
            var FineDto = _mapper.Map<CarFine>(carFineDto);
            FineDto = await _carFineRepository.AddFineOnCar(FineDto);
            return _mapper.Map<CarFineDto>(FineDto);

            
        }

        public async Task<CarFineDto> GetByCheckAndCarNumber(string Carnumber, string Checknumber)
        {
            var getCarFinedto = await _carFineRepository.GetCarFineCheckAndCarNumber(Carnumber, Checknumber);
            return _mapper.Map<CarFineDto>(getCarFinedto);
        }

        public async Task<CarFineDto> UpdateFine(string CarNumber, string CheckNumber, string Paystatus) 
        {
            var GetFromCardFine = await _carFineRepository.Update(CarNumber,CheckNumber,Paystatus);
            return _mapper.Map<CarFineDto>(GetFromCardFine);
        }

    }
}
