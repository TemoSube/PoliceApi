﻿using AutoMapper;
using PoliceAPI.Dtos;
using PoliceAPI.Entities;
using PoliceAPI.Repositories;

namespace PoliceAPI.Services
{
    public class CarInfoService : ICarInfoServiece
    {
        private readonly ICarInfoRepository _carInfoRepository;
        private readonly IMapper _mapper;
        public CarInfoService( ICarInfoRepository carInfoRepository, IMapper mapper)
        {

            _carInfoRepository = carInfoRepository;
            _mapper = mapper;

        }
        public IEnumerable<CarInfoDto> GetAllCarInformation()
        {
             var GetCarInfo = _carInfoRepository.GetAllN().ToList();
             return _mapper.Map<IEnumerable<CarInfoDto>>(GetCarInfo);
           
        }


        public CarInfoDto AddCarInfo(CarInfoDto carInfoDto)
        {
            var CreateNewInfoCar = _mapper.Map<CarInfo>(carInfoDto);
            CreateNewInfoCar = _carInfoRepository.AddCarInfo(CreateNewInfoCar);
            return _mapper.Map<CarInfoDto>(CreateNewInfoCar);
        }

        

        public CarInfoDto GetCarInfoByCarNumber(string CarNumber)
        {


            var getcarninfobyid = _carInfoRepository.GetByCarNumber(CarNumber);
            return _mapper.Map<CarInfoDto>(getcarninfobyid);
        }

        public void UpdateCarInfo(CarInfoDto carInfoDto)
        {
            var change = _mapper.Map<CarInfo>(carInfoDto);
            _carInfoRepository.Update(change);
        }
    }
}
