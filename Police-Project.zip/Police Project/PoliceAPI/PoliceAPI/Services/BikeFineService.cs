﻿using AutoMapper;
using PoliceAPI.Dtos;
using PoliceAPI.Entities;
using PoliceAPI.Repositories;
using System.Net;
using System.Net.Mail;

namespace PoliceAPI.Services
{
    public class BikeFineService : IBikeFineService
    {
        private readonly IBikeFineRepostory _repo;
        private readonly IMapper _mapper; 
        


        public BikeFineService(IBikeFineRepostory repo, IMapper mapper)
        {
            _repo = repo;
            _mapper = mapper;
            
        }

        public async Task<BikeFineDto> AddFineOnBike(BikeFineDto bikeFineDto)
        {
            var bikeord = _mapper.Map<BikeFine>(bikeFineDto);
            bikeord = await _repo.AddFine(bikeord);

            

            return _mapper.Map<BikeFineDto>(bikeord);
        }

 
        public async Task<BikeFineDto> GetByCheckAndBikeNumber(string Bikenumber, string Checknumber)
        {
            var bikecheck =  await _repo.GetBikeFineCheckAndCarNumber(Bikenumber, Checknumber);
            return  _mapper.Map<BikeFineDto>(bikecheck);
        }

        public async Task<BikeFineDto> Update(string BikeNumber, string CheckNumber, string payAndStatus)
        {
            var BikeStatusChanger = await _repo.Update(BikeNumber, CheckNumber, payAndStatus);
            return _mapper.Map<BikeFineDto>(BikeStatusChanger);
        }


    }
}
