﻿using PoliceAPI.ForEmail;

namespace PoliceAPI.Services
{
    public interface IGmailService
    {

        public Task SendEmailAsync(MailRequest mailRequest);

    }
}
