
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using PoliceAPI.Entities;
using PoliceAPI.ForEmail;
using PoliceAPI.Repositories;
using PoliceAPI.Services;
using System.Text;
using Microsoft.Extensions.Configuration;



namespace PoliceAPI
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            builder.Services.AddSwaggerGen(option =>
            {
                option.SwaggerDoc("v1", new OpenApiInfo { Title = "Demo API", Version = "v1" });
                option.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                {
                    In = ParameterLocation.Header,
                    Description = "Please enter a valid token",
                    Name = "Authorization",
                    Type = SecuritySchemeType.Http,
                    BearerFormat = "JWT",
                    Scheme = "Bearer"
                });
                option.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Reference = new OpenApiReference
                            {
                                Type=ReferenceType.SecurityScheme,
                                Id="Bearer"
                            }
                        },
                        new string[]{}
                    }
                });
            });

            // Add JwtBearer authentication
            builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                .AddJwtBearer(options =>
                {
                    options.TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidateIssuerSigningKey = true,
                        IssuerSigningKey = new SymmetricSecurityKey(Encoding.ASCII
                            .GetBytes(builder.Configuration.GetSection("AppSettings:Token").Value)),
                        ValidateIssuer = false,
                        ValidateAudience = false
                    };
                });

            // Add services
            builder.Services.AddControllers();
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddStackExchangeRedisCache(options =>
            {
               
                var redisConnectionString = builder.Configuration["RedisCache:ConnectionString"];
                options.Configuration = redisConnectionString;
            });
            builder.Services.AddDbContext<PoliceApiDbContext>(options =>
                options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));
            builder.Services.AddAutoMapper(typeof(Program));
            builder.Services.Configure<EmailSettings>(builder.Configuration.GetSection("EmailSettings"));


            builder.Services.AddScoped<ICarInfoServiece, CarInfoService>();
            builder.Services.AddScoped<IBikeInfoService, BikeInfoService>();
            builder.Services.AddScoped<IBikeFineService, BikeFineService>();
            builder.Services.AddScoped<ICarFineService, CarFineServices>();
            builder.Services.AddScoped<IGmailService, GmailService>();



            builder.Services.AddScoped<ICarInfoRepository, CarInfoRepository>();
            builder.Services.AddScoped<IbikeInfoRepository, BikeInfoRepository>();
            builder.Services.AddScoped<IAuthRepository, AuthRepository>();
            builder.Services.AddScoped<IBikeFineRepostory, BikeFinerepository>();
            builder.Services.AddScoped<ICarFineRepository, CarFineRepository>();

            var app = builder.Build();

            app.UseSwagger();
            app.UseSwaggerUI();


            app.UseAuthentication();
            app.UseAuthorization();

            app.MapControllers();

            app.Run();
        }
    }
}