﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PoliceAPI.Dtos;
using PoliceAPI.Entities;
using PoliceAPI.ForEmail;
using PoliceAPI.Repositories;
using PoliceAPI.Services;
using PoliceAPI.UserFilter;

namespace PoliceAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BikeFineController : ControllerBase
    {

        private readonly IBikeFineService _bikeFineService;
        private readonly IGmailService _gmailService;
        //private readonly PoliceApiDbContext _context;
        //private readonly IBikeFineRepostory _bikeFineRepostory;
        public BikeFineController(IBikeFineService bikeFineService, IGmailService gmailService, PoliceApiDbContext context, IBikeFineRepostory bikeFineRepostory)
        {
            _bikeFineService = bikeFineService;
            _gmailService = gmailService;
            //_context = context;
            //_bikeFineRepostory = bikeFineRepostory;
        }

        
        [HttpGet("CheckAndBikeNumber")]
        public async Task<ActionResult<BikeFineDto>> GetFineForBike(string BikeNumber, string CheckNumber)
        {

            var BikeFineGet = await _bikeFineService.GetByCheckAndBikeNumber(BikeNumber, CheckNumber);
            if (BikeFineGet == null)
            {
                return BadRequest("es nomeri ar moidzebna");

            }


            return Ok(BikeFineGet);


        }

        [HttpPost]
        public async Task<ActionResult<BikeFineDto>> PostFineOnBikeAsync([FromBody] BikeFineDto bikeFineDto)
        {
            //if (bikeFineDto.PayStatus == "string") 
            //{
            //    bikeFineDto.PayStatus = "Unpaid";
            
            
            //}

            var addFineOnBike = await _bikeFineService.AddFineOnBike(bikeFineDto);
            if (addFineOnBike == null)
            {
                return BadRequest("es nomeri ar moidzebna");

            }

            try
            {
                MailRequest mailrequest = new MailRequest();
                mailrequest.ToEmail = bikeFineDto.Gmail;
                mailrequest.Subject = @"POLICE DEPARTMENT";
                mailrequest.Body = $"mototcikletis nomeri: {bikeFineDto.BikeNumber} chekis nomeri: {bikeFineDto.CheckNumber}";
                await _gmailService.SendEmailAsync(mailrequest);
            }
            catch (Exception ex)
            {
                throw;
            }
            return Ok(addFineOnBike);

        }

        [HttpPut/*("{BikeNumber CheckNumber}")*/]
        public async Task<ActionResult<BikeFineDto>> Edit(string BikeNumber, string CheckNumber, PayAndStatusForBikeDto payAndStatus)
        {

            

            try
            {
                // Update the status of the bike fine
                var updatedStatus = await _bikeFineService.Update(BikeNumber, CheckNumber, payAndStatus.PayStatus);

                return Ok(updatedStatus);
            }
            catch (Exception ex)
            {
                // Handle exceptions
                return StatusCode(500, "Internal server error");
            }
        }
    }
    }

