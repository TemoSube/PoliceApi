﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PoliceAPI.Dtos;
using PoliceAPI.Services;
using PoliceAPI.UserFilter;

namespace PoliceAPI.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class CarInfoController : ControllerBase
    {
        ICarInfoServiece _carinfoservice;
        public CarInfoController(ICarInfoServiece carinfoservice)
        {
            _carinfoservice = carinfoservice;
        }
        //[Authorize]
        //[RoleFilter("Police")]
        [HttpGet] 
        public ActionResult<IEnumerable<CarInfoDto>> GetAll()
        {
            var carallinfo = _carinfoservice.GetAllCarInformation();

            if (carallinfo == null) 
            {
                return NotFound();
            
            }
            return Ok(carallinfo);


        }
        //rogor shevqmnat custome [HttpGet ("id")] esetebi
        [HttpGet("CarNumber")]
        public ActionResult<CarInfoDto> GetByCarNumber(string CarNumber) 
        {
        var getbyid = _carinfoservice.GetCarInfoByCarNumber(CarNumber);
        return Ok(getbyid);

        
        }

        [HttpPost]
        public ActionResult<CarInfoDto> Post([FromBody] CarInfoDto carInfoDto) 
        {
            var CreateNewCar = _carinfoservice.AddCarInfo(carInfoDto);
            return Ok(CreateNewCar);  
        }

    }

    }

