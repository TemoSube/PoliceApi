﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Distributed;
using PoliceAPI.Dtos;
using PoliceAPI.Services;
using PoliceAPI.UserFilter;
using System.Collections.Generic;

namespace PoliceAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class BikeInfoController : ControllerBase
    {
        private readonly IBikeInfoService _BikeInfoService;
        private readonly IDistributedCache _cache;

        public BikeInfoController(IBikeInfoService BikeInfoService, IDistributedCache cache)
        {
            _BikeInfoService = BikeInfoService;
            _cache = cache;

        }
        [HttpGet]
        
        public ActionResult<IEnumerable<BikeInfoDto>> GetAll()
        {
            var allBikeInfo =  _BikeInfoService.GetAllInfoBike().ToList();
            if (allBikeInfo  == null) 
            {
                return NotFound();
            
            } 
            return Ok(allBikeInfo);

        }

        [HttpGet("BikeNumber")]
        
        public async Task<ActionResult<BikeInfoDto>> GetById(string BikeNumber) 
        {
        var getbyid = await _BikeInfoService.GetBikeInfoByBikeNumber(BikeNumber);
            if (getbyid == null) 
            {
                return NotFound();
            }
            return Ok(getbyid);
        
        
        }

        [HttpPost]
        public ActionResult<BikeInfoDto> AddBike([FromBody] BikeInfoDto bikeInfoDto) 
        {
        var addbikeinfo = _BikeInfoService.AddBikeInfo(bikeInfoDto);
            return Ok(addbikeinfo);

            //if (!ModelState.IsValid)
            //{
            //    return BadRequest(ModelState);
            //}

            //_carinfoservice.AddCarInfo(carInfoDto);
            //return CreatedAtAction(nameof(GetById), new { id = carInfoDto.Id }, carInfoDto);

        }
    }
}
