﻿using Microsoft.EntityFrameworkCore;
using PoliceAPI.Entities;

namespace PoliceAPI.Repositories
{
    public class BikeFinerepository : IBikeFineRepostory
    {
        PoliceApiDbContext _context;
        public BikeFinerepository(PoliceApiDbContext context)
        {
            _context = context;
        }


        public async Task<BikeFine> AddFine(BikeFine bikeFine)
        {

             await _context.BikeFines.AddAsync(bikeFine);
             _context.SaveChanges();
             return bikeFine;

        }

        public async Task<BikeFine> GetBikeFineCheckAndCarNumber(string BikeNumber, string CheckNumber)
        {

           return await _context.BikeFines.FirstOrDefaultAsync(x => x.BikeNumber == BikeNumber && x.CheckNumber == CheckNumber);
           


        }

        public async Task<BikeFine> Update(string bikeNumber,string CheckNumber, string payStatus)
        {
            var existingBikeFine = await _context.BikeFines.FirstOrDefaultAsync(x => x.BikeNumber == bikeNumber && x.CheckNumber == CheckNumber);

            if (existingBikeFine != null)
            {
                // Update the existing bike fine entity with the new pay status
                existingBikeFine.PayStatus = payStatus;

                // Save changes to the database
                await _context.SaveChangesAsync();
            }

            return existingBikeFine;
        }
    }
}
