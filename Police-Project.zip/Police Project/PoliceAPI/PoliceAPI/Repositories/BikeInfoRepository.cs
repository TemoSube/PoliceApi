﻿using Microsoft.EntityFrameworkCore;
using PoliceAPI.Entities;
using System.Dynamic;

namespace PoliceAPI.Repositories
{
    public class BikeInfoRepository : IbikeInfoRepository
    {
        private readonly PoliceApiDbContext _context;
        public BikeInfoRepository(PoliceApiDbContext context) 
        {
            _context = context;
        }

        public IEnumerable<BikeInfo> GetAllB()
        {
            return _context.BikeInfos.ToList();
        }



        public BikeInfo CreateBikeInfo(BikeInfo bikeInfo)
        {
            _context.BikeInfos.Add(bikeInfo);
            _context.SaveChanges();
            return bikeInfo;
            
        }

       

        public BikeInfo GetById(string BikeNumber)
        {
            //return _context.BikeInfos.Find(id);
            return _context.BikeInfos.FirstOrDefault(x => x.BikeNumber == BikeNumber);
        }

        public void Update(BikeInfo bikeInfo)
        {
            _context.Entry(bikeInfo).State = EntityState.Modified;
            _context.SaveChanges();
        }
    }
}
